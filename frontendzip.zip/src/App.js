import React, { useState } from "react";
import ImageList from "./component/ImageList";
import ImageDetails from "./component/ImageDetails";

const App = () => {
  const [defaultImage, setDefaultImage] = useState(null);

  const handleDefaultImageClick = (image) => {
    setDefaultImage(image);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-4xl mb-4">Image Gallery</h1>
      <div className="grid grid-cols-3 gap-4">
        {/* {defaultImage && (
          // <div className="col-span-2">
          //   <ImageDetails imageDetails={defaultImage} />
          // </div>
        )} */}
        <div className="col-span-1">
          <ImageList setDefaultImage={handleDefaultImageClick} />
        </div>
      </div>
    </div>
  );
};

export default App;


