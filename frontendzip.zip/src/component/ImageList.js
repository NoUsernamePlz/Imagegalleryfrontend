import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

const ImageList = ({ setDefaultImage }) => {
  const [images, setImages] = useState([]);

  useEffect(() => {
    const fetchImages = async () => {
      try {
        const response = await axios.get("/api/images");
        setImages(response.data);
        console.log(response.data);
      } catch (error) {
        console.error("Error fetching images:", error);
      }
    };

    fetchImages();
    
  }, []);

  return (
    <div>
      <div className="grid grid-cols-3 gap-4">
        {images.length>0 && images.map((image) => (
           <Link key={image._id} to="#" onClick={() => setDefaultImage(image)}>
             <img src={image.frontimageUrl} alt="Gallery" className="w-full h-48 object-cover" />
            
          
           </Link>
        ))}
      </div>
    </div>
  );
};

export default ImageList;
