import React from "react";

const ImageDetails = ({ imageDetails }) => {
    console.log(imageDetails);
  return (
    <div>
      <h1>Image Details</h1>
      <img src={imageDetails.imageUrl} alt="Details" className="w-full h-96 object-cover mb-4" />
      <pre>{JSON.stringify(imageDetails.metadata, null, 2)}</pre>
    </div>
  );
};

export default ImageDetails;
